module com.example.cab302_week9 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires jdk.javadoc;

    opens com.example.cab302_week9 to javafx.fxml;
    exports com.example.cab302_week9;
}