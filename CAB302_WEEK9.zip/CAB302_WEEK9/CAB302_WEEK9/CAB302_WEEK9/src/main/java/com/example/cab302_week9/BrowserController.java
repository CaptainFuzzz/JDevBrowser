package com.example.cab302_week9;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.util.Objects;

public class BrowserController {
    @FXML
    public TextField urlTextField;
    @FXML
    public Button goButton;
    @FXML
    public Text LogoText;
    @FXML
    public TextField searchTextField;
    @FXML
    public Button themeToggleButton;
    @FXML
    private VBox root;

    // No-argument constructor
    public BrowserController() {

    }

    // This method toggles between the dark and light themes
    @FXML
    public void toggleTheme() {
        // Ensure these paths are correct relative to the classpath root
        String darkThemePath = Objects.requireNonNull(getClass().getResource("/com/example/cab302_week9/dark-theme.css")).toExternalForm();
        String lightThemePath = Objects.requireNonNull(getClass().getResource("/com/example/cab302_week9/light-theme.css")).toExternalForm();

        if (root.getStylesheets().contains(darkThemePath)) {
            root.getStylesheets().remove(darkThemePath);
            root.getStylesheets().add(lightThemePath);
        } else {
            root.getStylesheets().remove(lightThemePath);
            root.getStylesheets().add(darkThemePath);
        }
    }


}
